<a href="{{ route('home') }}"
    class="flex items-center text-2xl font-bold text-blue-600 hover:text-blue-800 transition-colors">
    <img src="{{ asset('logo.png') }}" alt="Logo EcoReco" class="w-8 h-8 mr-2">
    <span>EcoReco</span>
</a>
